// console.log('Brincando com NodeJS');
for (i = 0; i < 11; i++){
  console.log(i);
}
