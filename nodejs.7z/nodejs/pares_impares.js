// Separar de 1 a 100 os números pares e impares
// Dica: Use FOR e IF
// Rodar com NodeJS

for (numero = 1; numero <= 100; numero++){
  if(numero%2=0){
    console.log(numero + ' é par!');
  }else {
    console.log(numero + ' é impar!');
  }
}
